<?php
// Polls Airtel and settles the payment. Payment status + booking status change in ONE transaction.
// Final states (SUCCESS / FAILED) are immutable, so repeated polls are idempotent.
require_once __DIR__ . '/airtel.php';

handle(function () {
  $id = trim((string) ($_GET['id'] ?? ''));
  $st = db()->prepare('SELECT status FROM payments WHERE transaction_id = ?');
  $st->execute([$id]);
  $p = $st->fetch();
  if (!$p) throw new HttpError('Unknown transaction id.', 404);
  if ($p['status'] !== 'PENDING') json_out(['transactionId' => $id, 'status' => $p['status']]);

  try {
    $r   = airtel_check_status($id);
    $raw = (string) ($r['data']['transaction']['status'] ?? '');
  } catch (Throwable $e) {
    json_out(['transactionId' => $id, 'status' => 'PENDING']);   // Airtel unreachable: keep polling
  }
  $new = ['TS' => 'SUCCESS', 'SUCCESS' => 'SUCCESS', 'TF' => 'FAILED', 'TE' => 'FAILED', 'FAILED' => 'FAILED'][$raw] ?? 'PENDING';

  $final = with_tx(function (PDO $pdo) use ($id, $new) {
    $s = $pdo->prepare('SELECT booking_id, status FROM payments WHERE transaction_id = ? FOR UPDATE');
    $s->execute([$id]);
    $pay = $s->fetch();
    if ($pay['status'] !== 'PENDING') return $pay['status'];       // someone else already settled it
    $pdo->prepare('UPDATE payments SET status = ?, last_checked = NOW() WHERE transaction_id = ?')->execute([$new, $id]);
    if ($new === 'SUCCESS') {
      $pdo->prepare("UPDATE bookings SET status = 'paid' WHERE booking_id = ? AND status = 'pending_payment'")->execute([$pay['booking_id']]);
    }
    return $new;
  });
  json_out(['transactionId' => $id, 'status' => $final]);
});
