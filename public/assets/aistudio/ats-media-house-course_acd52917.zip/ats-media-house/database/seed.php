<?php
// Unit 6.5 Data population techniques.  Run once after importing schema.sql:
//   C:\xampp\php\php.exe database\seed.php [admin-password]
// Creates the admin login (password hashed) and ~15 sample customers/bookings for testing.
if (PHP_SAPI !== 'cli') exit('CLI only.');
require __DIR__ . '/../app/bootstrap.php';

$password = $argv[1] ?? bin2hex(random_bytes(5));
$pdo = db();
$pdo->prepare('INSERT INTO admin_users (username, password_hash) VALUES (?, ?)
               ON DUPLICATE KEY UPDATE password_hash = VALUES(password_hash)')
    ->execute(['admin', password_hash($password, PASSWORD_DEFAULT)]);
echo "Admin login  ->  username: admin   password: $password\n";

if ((int) $pdo->query('SELECT COUNT(*) FROM bookings')->fetchColumn() > 0) { echo "Bookings already exist; sample data skipped.\n"; exit; }

$first = ['Chanda', 'Mwila', 'Bwalya', 'Natasha', 'Kondwani', 'Thandiwe', 'Mutale', 'Precious', 'Joseph', 'Esther'];
$last  = ['Mwansa', 'Phiri', 'Banda', 'Tembo', 'Zulu', 'Lungu', 'Mumba', 'Chisenga'];
$notes = ['Venue is Mulungushi Conference Centre', 'Outdoor family shoot at Munda Wanga', 'Need 200 edited photos', 'Graduation at UNZA', null, 'Corporate headshots for 12 staff', 'Wedding venue near Kabulonga'];
$codes = array_column(Service::active(), 'code');

with_tx(function () use ($first, $last, $notes, $codes) {      // all-or-nothing: either every sample row is saved or none
  mt_srand(42);                                                // same sample data every run
  for ($i = 0; $i < 15; $i++) {
    $f = [
      'fullName' => $first[array_rand($first)] . ' ' . $last[array_rand($last)],
      'phone'    => sprintf('097%07d', mt_rand(0, 9999999)),
      'email'    => $i % 3 === 0 ? 'client' . $i . '@example.com' : '',
      'service'  => $codes[array_rand($codes)],
      'eventDate'=> date('Y-m-d', strtotime('+' . mt_rand(1, 120) . ' days')),
      'notes'    => $notes[array_rand($notes)] ?? '',
    ];
    [$id] = create_booking(booking_input($f));
    if ($i % 2 === 0) Booking::markPaid($id);                  // half of them paid, so the reports have data
  }
});
echo "Sample data inserted.\n";
