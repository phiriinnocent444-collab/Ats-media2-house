// Unit 9: JavaScript + DOM for the PHP pages (embedded with <script src>, plain functions, form interaction)
document.addEventListener('DOMContentLoaded', function () {

  // 9.6 Interacting with HTML forms: live price preview when a package is chosen
  var select = document.querySelector('.js-price-source');
  var preview = document.getElementById('price-preview');
  function showPrice() {
    if (!select || !preview) return;
    var opt = select.options[select.selectedIndex];
    var price = opt && opt.dataset.price;
    preview.textContent = price ? 'Amount due: K' + Number(price).toLocaleString('en-ZM', { minimumFractionDigits: 2 }) : '';
  }
  if (select) { select.addEventListener('change', showPrice); showPrice(); }

  // 9.4 DOM: character counter for any textarea with data-counter
  document.querySelectorAll('textarea[data-counter]').forEach(function (ta) {
    var out = document.getElementById(ta.dataset.counter);
    function update() { out.textContent = ta.value.length + ' / ' + ta.maxLength; }
    ta.addEventListener('input', update); update();
  });

  // 9.5 Functions: filter table rows as you type
  document.querySelectorAll('input[data-filter]').forEach(function (box) {
    box.addEventListener('input', function () {
      var term = box.value.toLowerCase();
      document.querySelectorAll('#' + box.dataset.filter + ' tr').forEach(function (row, i) {
        if (i === 0) return;                                   // keep the header row
        row.style.display = row.textContent.toLowerCase().indexOf(term) === -1 ? 'none' : '';
      });
    });
  });

  // Ask before destructive actions
  document.querySelectorAll('form[data-confirm]').forEach(function (f) {
    f.addEventListener('submit', function (e) { if (!window.confirm(f.dataset.confirm)) e.preventDefault(); });
  });
});
