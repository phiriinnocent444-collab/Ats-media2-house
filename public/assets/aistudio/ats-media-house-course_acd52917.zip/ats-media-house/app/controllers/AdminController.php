<?php
// Password-protected admin area: CRUD for bookings, services and gallery + reports.
class AdminController extends Controller {
  public function __construct() {
    if (empty($_SESSION['admin'])) { flash('Please log in.', 'err'); redirect(url('auth/login')); }   // the "gate"
    header('Cache-Control: no-store');                                                                // Unit 6.1 header: never cache admin pages
  }

  public function dashboard(): void { $this->render('admin/dashboard', ['s' => Booking::stats(), 'up' => Booking::upcoming()], 'Dashboard'); }

  public function bookings(): void {
    $q = trim((string) ($_GET['q'] ?? '')); $status = (string) ($_GET['status'] ?? '');
    $this->render('admin/bookings', ['rows' => Booking::all($q, $status), 'q' => $q, 'status' => $status], 'Bookings');
  }

  public function booking_action(): void {
    if (!$this->isPost()) redirect(url('admin/bookings'));
    csrf_check(); $id = (string) ($_POST['id'] ?? '');
    try {
      switch ($_POST['do'] ?? '') {
        case 'paid':   Booking::markPaid($id);  flash('Booking marked as paid.'); break;
        case 'cancel': Booking::cancel($id);    flash('Booking cancelled.'); break;
        case 'delete': flash('Booking ' . delete_booking($id) . '.'); break;
        default: flash('Unknown action.', 'err');
      }
    } catch (HttpError $e) { flash($e->getMessage(), 'err'); }
    redirect(url('admin/bookings'));
  }

  public function booking_edit(): void {
    $id = (string) ($_GET['id'] ?? ''); $errors = [];
    try { $b = find_booking($id); } catch (HttpError $e) { flash('Booking not found.', 'err'); redirect(url('admin/bookings')); }
    if ($this->isPost()) {
      csrf_check(); [$errors, $clean] = Validator::booking($_POST);
      if (!$errors) {
        try { update_booking($id, booking_input($_POST)); flash('Booking updated.'); redirect(url('admin/bookings')); }
        catch (HttpError $e) { $errors['form'] = $e->getMessage(); }
      }
    }
    $defaults = $this->isPost() ? [] : ['fullName' => $b['fullName'], 'phone' => $b['phone'], 'email' => $b['email'], 'service' => $b['service'], 'eventDate' => $b['eventDate'], 'notes' => $b['notes']];
    $this->render('page/book', ['services' => Service::active(), 'errors' => $errors, 'defaults' => $defaults, 'action' => url('admin/booking_edit', ['id' => $id]), 'submit' => 'Update booking'], 'Edit booking ' . $id);
  }

  public function services(): void { $this->render('admin/services', ['rows' => Service::all()], 'Services'); }

  public function service_save(): void {
    if (!$this->isPost()) redirect(url('admin/services'));
    csrf_check(); $id = (int) ($_POST['id'] ?? 0) ?: null;
    $err = Service::save($id, $_POST);
    $err ? flash($err, 'err') : flash($id ? 'Service updated.' : 'Service added.');
    redirect(url('admin/services'));
  }

  public function gallery(): void { $this->render('admin/gallery', ['photos' => Gallery::all()], 'Gallery admin'); }

  public function gallery_upload(): void {
    if (!$this->isPost()) redirect(url('admin/gallery'));
    csrf_check();
    try {
      $title = trim((string) ($_POST['title'] ?? '')); if ($title === '') throw new RuntimeException('Give the photo a title.');
      [$file, $thumb] = ImageTool::process($_FILES['photo'] ?? []);
      Gallery::add($title, $file, $thumb, $_SESSION['admin']['id']);
      flash('Photo uploaded.');
    } catch (RuntimeException $e) { flash($e->getMessage(), 'err'); }
    redirect(url('admin/gallery'));
  }

  public function gallery_delete(): void {
    if ($this->isPost()) { csrf_check(); Gallery::remove((int) ($_POST['id'] ?? 0)); flash('Photo deleted.'); }
    redirect(url('admin/gallery'));
  }

  public function reports(): void {
    $this->render('admin/reports', ['svc' => Booking::byService(), 'month' => Booking::byMonth(), 'top' => Booking::topCustomers()], 'Reports');
  }
}
