<?php
// Unit 6.3 Session management and password protected pages
class AuthController extends Controller {
  public function login(): void {
    $error = '';
    if ($this->isPost()) {
      csrf_check();
      if (($_SESSION['lock_until'] ?? 0) > time()) {
        $error = 'Too many attempts. Wait a minute and try again.';
      } else {
        $u = AdminUser::find(trim((string) ($_POST['username'] ?? '')));
        if ($u && password_verify((string) ($_POST['password'] ?? ''), $u['password_hash'])) {
          session_regenerate_id(true);                                  // new session id after login (stops session fixation)
          $_SESSION['admin'] = ['id' => (int) $u['admin_id'], 'name' => $u['username']];
          $_SESSION['fails'] = 0;
          setcookie('ats_user', $u['username'], ['expires' => time() + 30 * 86400, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax']); // Unit 6.2 cookie
          redirect(url('admin/dashboard'));
        }
        $_SESSION['fails'] = ($_SESSION['fails'] ?? 0) + 1;
        if ($_SESSION['fails'] >= 5) { $_SESSION['lock_until'] = time() + 60; $_SESSION['fails'] = 0; }
        $error = 'Wrong username or password.';
      }
    }
    $this->render('auth/login', ['error' => $error, 'remembered' => $_COOKIE['ats_user'] ?? ''], 'Admin login');
  }

  public function logout(): void {
    if ($this->isPost()) { csrf_check(); $_SESSION = []; session_destroy(); }
    redirect(url('auth/login'));
  }
}
