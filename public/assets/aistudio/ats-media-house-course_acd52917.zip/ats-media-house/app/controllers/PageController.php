<?php
// Public pages: PHP-rendered booking form (sticky), thank-you, gallery, course map.
class PageController extends Controller {
  public function index(): void { redirect(url('page/book')); }

  public function book(): void {
    $errors = []; $defaults = ['fullName' => $_COOKIE['ats_name'] ?? '', 'service' => $_GET['service'] ?? ''];   // cookie remembers the name
    if ($this->isPost()) {
      csrf_check();
      [$errors, $clean] = Validator::booking($_POST);
      if (!$errors) {
        try {
          $b = Booking::create($_POST);
          setcookie('ats_name', $clean['name'], ['expires' => time() + 30 * 86400, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax']);
          if ($clean['email'] !== '') {
            send_mail($clean['email'], 'ATS media house booking ' . $b['id'],
              "Hello {$clean['name']},\n\nYour booking {$b['id']} for {$b['serviceLabel']} on " . nice_date($b['eventDate']) .
              " (" . money($b['amount']) . ") is saved and awaiting payment.\n\nATS media house");
          }
          $_SESSION['last_booking'] = $b['id'];
          redirect(url('page/thanks'));                                  // Post/Redirect/Get: refresh will not re-submit
        } catch (HttpError $e) { $errors['form'] = $e->getMessage(); }
      }
    }
    $this->render('page/book', ['services' => Service::active(), 'errors' => $errors, 'defaults' => $defaults, 'action' => url('page/book'), 'submit' => 'Save booking'], 'Book a session');
  }

  public function thanks(): void {
    $id = $_SESSION['last_booking'] ?? '';                               // only the person who just booked can see it
    if ($id === '') redirect(url('page/book'));
    $this->render('page/thanks', ['b' => find_booking($id)], 'Booking saved');
  }

  public function gallery(): void { $this->render('page/gallery', ['photos' => Gallery::all()], 'Gallery'); }

  public function course(): void {
    $map = json_decode(file_get_contents(__DIR__ . '/../course_map.json'), true) ?: [];
    $this->render('page/course', ['map' => $map], 'Course map');
  }
}
