<?php
// Unit 3.4 Creating your own functions

function h($s): string { return htmlspecialchars((string) $s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }   // stop XSS
function money($n): string { return 'K' . number_format((float) $n, 2); }
function nice_date(string $d): string { return date('D, j M Y', strtotime($d)); }                         // Unit 6.2

/** Days from today until $date (negative = in the past). */
function days_until(string $date): int {
  return (int) (new DateTime('today'))->diff(new DateTime($date))->format('%r%a');
}

function url(string $route = '', array $q = []): string {
  return rtrim(dirname($_SERVER['SCRIPT_NAME']), '/') . '/index.php?r=' . $route . ($q ? '&' . http_build_query($q) : '');
}

/** Unit 6.1 HTTP headers: redirect, then stop the script. */
function redirect(string $to) { header('Location: ' . $to); exit; }

function flash(?string $msg = null, string $type = 'ok'): ?array {
  if ($msg !== null) { $_SESSION['flash'] = [$type, $msg]; return null; }
  $f = $_SESSION['flash'] ?? null; unset($_SESSION['flash']); return $f;
}

// CSRF protection: every POST form carries a secret token that other sites cannot know
function csrf_field(): string {
  $_SESSION['csrf'] = $_SESSION['csrf'] ?? bin2hex(random_bytes(16));
  return '<input type="hidden" name="csrf" value="' . h($_SESSION['csrf']) . '">';
}
function csrf_check(): void {
  if (!hash_equals($_SESSION['csrf'] ?? '', (string) ($_POST['csrf'] ?? ''))) { http_response_code(400); exit('Invalid form token. Go back and try again.'); }
}

/** Unit 6.1 e-mail. XAMPP has no mail server by default, so every message is also written to storage/mail.log. */
function send_mail(string $to, string $subject, string $body): bool {
  $line = '[' . date('Y-m-d H:i:s') . "] TO: $to | $subject\n$body\n---\n";
  file_put_contents(__DIR__ . '/../storage/mail.log', $line, FILE_APPEND | LOCK_EX);
  $headers = "From: ATS media house <noreply@localhost>\r\nContent-Type: text/plain; charset=UTF-8";
  return @mail($to, $subject, $body, $headers);
}
