<p class="eyebrow">Portfolio</p><h2>Gallery</h2>
<?php if (!$photos): ?><p>No photos yet. An admin can upload some.</p><?php endif; ?>
<div class="grid-photos">
<?php foreach ($photos as $p): ?>
  <a href="../uploads/gallery/<?= h($p['filename']) ?>" target="_blank"><img src="../uploads/thumbs/<?= h($p['thumb']) ?>" alt="<?= h($p['title']) ?>" loading="lazy"><span><?= h($p['title']) ?></span></a>
<?php endforeach; ?>
</div>
