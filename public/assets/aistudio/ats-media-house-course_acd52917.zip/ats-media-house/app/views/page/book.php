<p class="eyebrow">Reserve your date</p><h2><?= $submit === 'Save booking' ? 'Book a session' : 'Edit booking' ?></h2>
<?php if ($submit === 'Save booking'): ?><p class="section-lede">Your details stay in the form if something needs fixing. After saving, confirm payment on WhatsApp (0772 300 053) or use Airtel Money on the <a href="../index.html#book">main booking page</a>.</p><?php endif; ?>
<div style="max-width:560px"><?php require __DIR__ . '/../partials/booking_form.php'; ?></div>
