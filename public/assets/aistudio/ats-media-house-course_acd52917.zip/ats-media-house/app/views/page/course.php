<p class="eyebrow">BSc 209 Web Technology</p><h2>Where each unit is used</h2>
<p class="section-lede">This table is read from <code>app/course_map.json</code> (Unit 5: PHP reading data) and printed with a <code>foreach</code> loop (Unit 2: loops).</p>
<input type="search" placeholder="Filter topics…" data-filter="course-table" aria-label="Filter">
<div class="scroll"><table class="table" id="course-table">
<tr><th>Unit</th><th>Topic</th><th>File</th><th>How it is done</th></tr>
<?php foreach ($map as $r): ?>
<tr><td><?= h($r['unit']) ?></td><td><?= h($r['topic']) ?></td><td><code><?= h($r['file']) ?></code></td><td><?= h($r['how']) ?></td></tr>
<?php endforeach; ?>
</table></div>
