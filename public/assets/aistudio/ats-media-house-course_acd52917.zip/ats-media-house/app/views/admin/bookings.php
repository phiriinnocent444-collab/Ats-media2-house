<h2>Bookings</h2>
<form method="get" class="filters"><input type="hidden" name="r" value="admin/bookings">
  <input name="q" value="<?= h($q) ?>" placeholder="Search name, reference or notes…" aria-label="Search">
  <select name="status" aria-label="Status"><option value="">All statuses</option>
    <?php foreach (['pending_payment', 'paid', 'cancelled'] as $st): ?><option <?= $status === $st ? 'selected' : '' ?>><?= $st ?></option><?php endforeach; ?></select>
  <button class="btn btn-solid" type="submit">Search</button>
</form>
<div class="scroll"><table class="table">
<tr><th>Ref</th><th>Client</th><th>Package</th><th>Date</th><th>Amount</th><th>Status</th><th>Actions</th></tr>
<?php foreach ($rows as $b): ?>
<tr><td><small><?= h($b['id']) ?></small></td><td><?= h($b['fullName']) ?><br><small>0<?= h($b['phone']) ?></small></td><td><?= h($b['serviceLabel']) ?></td>
<td><?= nice_date($b['eventDate']) ?></td><td><?= money($b['amount']) ?></td><td><span class="pill <?= h($b['status']) ?>"><?= h($b['status']) ?></span></td>
<td class="actions">
<?php if ($b['status'] === 'pending_payment'): ?><a class="btn btn-outline" href="<?= url('admin/booking_edit', ['id' => $b['id']]) ?>">Edit</a><?php endif; ?>
<?php foreach (['pending_payment' => [['paid', 'Mark paid'], ['cancel', 'Cancel']], 'paid' => [], 'cancelled' => []][$b['status']] as [$do, $label]): ?>
  <form method="post" action="<?= url('admin/booking_action') ?>" class="inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= h($b['id']) ?>"><input type="hidden" name="do" value="<?= $do ?>"><button class="btn btn-outline" type="submit"><?= $label ?></button></form>
<?php endforeach; ?>
<?php if ($b['status'] !== 'paid'): ?><form method="post" action="<?= url('admin/booking_action') ?>" class="inline" data-confirm="Delete this booking?"><?= csrf_field() ?><input type="hidden" name="id" value="<?= h($b['id']) ?>"><input type="hidden" name="do" value="delete"><button class="btn btn-outline" type="submit">Delete</button></form><?php endif; ?>
</td></tr>
<?php endforeach; if (!$rows): ?><tr><td colspan="7">No bookings found.</td></tr><?php endif; ?></table></div>
