<?php $flash = flash(); $admin = $_SESSION['admin'] ?? null; ?>
<!DOCTYPE html>
<html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($title) ?> | ATS media house</title>
<link rel="stylesheet" href="../css/style.css">
</head><body class="app">
<header class="site-header"><div class="frame">
  <a class="brand" href="../index.html"><span class="brand-mark">◎</span><span class="brand-text">ATS <em>media house</em></span></a>
  <nav>
    <a href="<?= url('page/book') ?>">Book</a>
    <a href="<?= url('page/gallery') ?>">Gallery</a>
    <a href="<?= url('page/course') ?>">Course map</a>
    <?php if ($admin): ?>
      <a href="<?= url('admin/dashboard') ?>">Dashboard</a>
      <a href="<?= url('admin/bookings') ?>">Bookings</a>
      <a href="<?= url('admin/services') ?>">Services</a>
      <a href="<?= url('admin/gallery') ?>">Photos</a>
      <a href="<?= url('admin/reports') ?>">Reports</a>
      <form method="post" action="<?= url('auth/logout') ?>" class="inline"><?= csrf_field() ?><button class="btn btn-ghost" type="submit">Log out (<?= h($admin['name']) ?>)</button></form>
    <?php else: ?><a href="<?= url('auth/login') ?>">Admin</a><?php endif; ?>
  </nav>
</div></header>
<main class="section"><div class="frame">
  <?php if ($flash): ?><p class="flash <?= h($flash[0]) ?>" role="status"><?= h($flash[1]) ?></p><?php endif; ?>
  <?php require $viewFile; ?>
</div></main>
<script src="../js/app.js"></script>
</body></html>
