<?php
class Booking {
  /** READ with search: Unit 4.7 FULLTEXT (notes) + LIKE (name) + exact id, and optional status filter. */
  public static function all(string $q = '', string $status = ''): array {
    $sql = BOOKING_SQL; $w = []; $p = [];
    if ($q !== '') {
      $ft = self::booleanQuery($q);
      $w[] = '(c.full_name LIKE ? OR b.booking_id = ?' . ($ft ? ' OR MATCH(b.notes) AGAINST (? IN BOOLEAN MODE)' : '') . ')';
      array_push($p, "%$q%", $q); if ($ft) $p[] = $ft;
    }
    if (in_array($status, ['pending_payment', 'paid', 'cancelled'], true)) { $w[] = 'b.status = ?'; $p[] = $status; }
    if ($w) $sql .= ' WHERE ' . implode(' AND ', $w);
    $st = db()->prepare($sql . ' ORDER BY b.created_at DESC LIMIT 200'); $st->execute($p);
    return $st->fetchAll();
  }

  /** Unit 8.4 regex: "wedding venue" -> "+wedding* +venue*" (all words, prefix match, ignores symbols). */
  public static function booleanQuery(string $q): string {
    $words = array_filter(preg_split('/[^\p{L}\p{N}]+/u', $q, -1, PREG_SPLIT_NO_EMPTY), fn($w) => mb_strlen($w) >= 3);
    return implode(' ', array_map(fn($w) => '+' . $w . '*', $words));
  }

  public static function create(array $in): array { [$id, $new] = create_booking(booking_input($in)); return find_booking($id); }

  /** UPDATE status: admin confirms a manual (e.g. WhatsApp) payment. Payment row + booking change are ONE transaction. */
  public static function markPaid(string $id): void {
    with_tx(function (PDO $pdo) use ($id) {
      $b = lock_booking($pdo, $id);
      if ($b['status'] !== 'pending_payment') throw new HttpError('Only unpaid bookings can be marked paid.', 409);
      if (count_payments($pdo, $id, true) > 0) throw new HttpError('An Airtel payment is still pending.', 409);
      $st = $pdo->prepare('SELECT c.phone, b.amount_due FROM bookings b JOIN customers c ON c.customer_id = b.customer_id WHERE b.booking_id = ?');
      $st->execute([$id]); $r = $st->fetch();
      $pdo->prepare("INSERT INTO payments (transaction_id, booking_id, msisdn, amount, status, error) VALUES (?,?,?,?, 'SUCCESS', 'Manual confirmation by admin')")
          ->execute([new_id('MAN'), $id, $r['phone'], $r['amount_due']]);
      $pdo->prepare("UPDATE bookings SET status = 'paid' WHERE booking_id = ?")->execute([$id]);
    });
  }

  public static function cancel(string $id): void {
    with_tx(function (PDO $pdo) use ($id) {
      $b = lock_booking($pdo, $id);
      if ($b['status'] === 'paid') throw new HttpError('Paid bookings cannot be cancelled here (refund first).', 409);
      $pdo->prepare("UPDATE bookings SET status = 'cancelled' WHERE booking_id = ?")->execute([$id]);
    });
  }

  public static function stats(): array {
    return db()->query("SELECT COUNT(*) AS total,
        SUM(status='pending_payment') AS pending, SUM(status='paid') AS paid, SUM(status='cancelled') AS cancelled,
        COALESCE(SUM(CASE WHEN status='paid' THEN amount_due END),0) AS revenue
        FROM bookings")->fetch();
  }

  public static function upcoming(int $limit = 5): array {
    $st = db()->prepare(BOOKING_SQL . " WHERE b.status <> 'cancelled' AND b.event_date >= CURDATE() ORDER BY b.event_date LIMIT $limit");
    $st->execute(); return $st->fetchAll();
  }

  // Unit 4.4 JOIN + 4.5 GROUP BY reports
  public static function byService(): array {
    return db()->query("SELECT s.label, COUNT(b.booking_id) AS bookings,
        COALESCE(SUM(CASE WHEN b.status='paid' THEN b.amount_due END),0) AS revenue
        FROM services s LEFT JOIN bookings b ON b.service_id = s.service_id
        GROUP BY s.service_id, s.label ORDER BY revenue DESC, bookings DESC")->fetchAll();
  }
  public static function byMonth(): array {
    return db()->query("SELECT DATE_FORMAT(event_date,'%Y-%m') AS month, COUNT(*) AS bookings, SUM(amount_due) AS value
        FROM bookings WHERE status <> 'cancelled' GROUP BY month HAVING COUNT(*) >= 1 ORDER BY month DESC LIMIT 12")->fetchAll();
  }
  public static function topCustomers(): array {
    return db()->query("SELECT c.full_name, c.phone, COUNT(*) AS bookings, SUM(b.amount_due) AS value
        FROM customers c JOIN bookings b ON b.customer_id = c.customer_id WHERE b.status <> 'cancelled'
        GROUP BY c.customer_id, c.full_name, c.phone ORDER BY value DESC LIMIT 5")->fetchAll();
  }
}
