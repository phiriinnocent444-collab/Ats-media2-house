<?php
// Unit 3.1 Multiple files: every page loads this one file, which pulls in everything else.
date_default_timezone_set('Africa/Lusaka');          // Unit 6.2 date & time
ob_start();                                           // Unit 6 misc: output buffering lets header() work after output
require_once __DIR__ . '/../api/booking_lib.php';     // db(), with_tx(), booking logic (shared with the JSON API)
require_once __DIR__ . '/functions.php';

// Unit 8.3 OOP: classes load automatically from core/, models/, controllers/
spl_autoload_register(function (string $class) {
  foreach (['core', 'models', 'controllers'] as $dir) {
    $f = __DIR__ . "/$dir/$class.php";
    if (is_file($f)) { require $f; return; }
  }
});

// Unit 6.3 Sessions: HttpOnly + SameSite cookie so scripts/other sites cannot read or abuse it
session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax', 'path' => '/']);
session_start();
