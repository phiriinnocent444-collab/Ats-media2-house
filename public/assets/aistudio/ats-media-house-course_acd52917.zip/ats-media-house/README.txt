ATS media house - booking site with Airtel Money (XAMPP)
=========================================================

FOLDER LAYOUT
  index.html, css/, js/   the website
  api/                    PHP backend (CRUD + ACID transactions)
  database/schema.sql     MySQL/MariaDB schema (4 InnoDB tables + seed packages)
  docs/ats_database_design.html   conceptual / logical / physical design, Chen ER diagram

SETUP (Windows XAMPP)
 1. Open XAMPP Control Panel and Start "Apache" and "MySQL".
 2. Copy this whole folder (ats-media-house) to  C:\xampp\htdocs\
 3. Open http://localhost/phpmyadmin  ->  Import  ->  choose database/schema.sql  ->  Go.
    (Creates the database "ats_media_house". If you used the OLD schema before, open
    schema.sql first and uncomment the four DROP TABLE lines, then import. This deletes old data.)
 4. Edit api/config.php:
      - db: keep root / empty password (XAMPP default)
      - admin_token: set a long random string
      - airtel client_id / client_secret from https://developers.airtel.africa
 5. Make sure the PHP curl extension is on: C:\xampp\php\php.ini  ->  extension=curl
    (remove the leading ; if present), then restart Apache.
 6. Check the backend:  http://localhost/ats-media-house/api/health.php
    It must say  "status":"ok"  and  "engine":"InnoDB".
 7. Open the site:      http://localhost/ats-media-house/

NOTES
 - Airtel env is "UAT" (test). Real money only works after Airtel approves you and you
   switch env to "PROD" in config.php.
 - Booking confirmations go to WhatsApp 0772 300 053 (change WHATSAPP_NUMBER in js/script.js).
ADMIN (CRUD) - send header  X-Admin-Token: <your admin_token>
  GET    api/bookings.php            list all bookings        GET  api/bookings.php?id=BK...
  PUT    api/bookings.php?id=BK...   edit an unpaid booking (JSON body, same fields as the form)
  DELETE api/bookings.php?id=BK...   delete (or cancel if it has payment history)
  GET    api/services.php?all=1      list packages (public GET without ?all shows active only)
  POST   api/services.php            {"code":"studio","label":"Studio Session","price":600}
  PUT    api/services.php?id=1       edit a package;   DELETE api/services.php?id=1
Example:
  curl -H "X-Admin-Token: YOURTOKEN" http://localhost/ats-media-house/api/bookings.php

==========================================================================
PHP APPLICATION (course-based build: BSc 209 Web Technology)
==========================================================================
After step 3 above (import schema.sql), create the admin login + sample data ONCE:
   C:\xampp\php\php.exe C:\xampp\htdocs\ats-media-house\database\seed.php  YourAdminPassword
(If you skip the password, a random one is printed. Change it for real use.)

Pages (all under http://localhost/ats-media-house/):
  app/index.php?r=page/book        PHP booking form (sticky, validated, e-mail, cookie, redirect)
  app/index.php?r=page/gallery     photo gallery
  app/index.php?r=page/course      table showing WHERE each unit of the course outline is used
  app/index.php?r=auth/login       admin login  -> dashboard, bookings (search/edit/mark paid/cancel/delete),
                                   services (CRUD), photos (upload + GD thumbnails), reports (JOIN/GROUP BY)
  lessons/hello.php, unit2_basics.php, mysqli_demo.php, http_demo.php, unit9_dom_js.html   unit demos
  docs/HOW_IT_WAS_DONE.md          step-by-step explanation mapped to the course outline

Scheduled job (Unit 8.2): daily reminders + closing stale payment prompts
   Windows Task Scheduler action:  C:\xampp\php\php.exe C:\xampp\htdocs\ats-media-house\cli\reminders.php
   Linux cron:                     0 8 * * * php /path/to/ats-media-house/cli/reminders.php

E-mail: XAMPP cannot send real mail by default. Every message is written to storage/mail.log so you
can see it; to send for real configure [mail function] in php.ini (SMTP) or sendmail_path.

Manual payments: the admin marks a booking "paid" after the client confirms on WhatsApp (0772 300 053);
this records a payment row and updates the booking in one transaction.

TESTING (done on PHP 8.3 + MariaDB 10.11): schema import, seed, all pages, validation, CSRF rejection,
duplicate booking handling, FULLTEXT search, edit/pay/cancel/delete rules, services CRUD, image upload
(real MIME check, resize, thumbnail), JSON API CRUD with admin token, CLI script, session login/logout.
Not tested here: real Airtel Money calls (need your approved credentials) and real e-mail delivery.
